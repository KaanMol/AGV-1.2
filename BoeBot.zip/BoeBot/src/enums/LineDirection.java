package enums;

public enum LineDirection {
    FORWARD,
    LEFT,
    RIGHT,
    STOP,
}
