package enums;

public enum WhiskerStatus {
    LEFT,
    RIGHT,
    BOTH
}
