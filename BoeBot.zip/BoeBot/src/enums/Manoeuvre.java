package enums;

public enum Manoeuvre {
    LEFT,
    RIGHT,
    NONE
}
