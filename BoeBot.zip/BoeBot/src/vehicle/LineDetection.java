package vehicle;

import enums.Direction;
import enums.LineDirection;
import hardware.LineFollower;
import interfaces.LineDetectionUpdater;
import interfaces.Updatable;
import common.Config;

import javax.sound.sampled.Line;

public class LineDetection implements Updatable {

    private LineDetectionUpdater callback;
    private LineFollower leftLineFollower;
    private LineFollower middleLineFollower;
    private LineFollower rightLineFollower;

    public LineDetection(LineDetectionUpdater callback) {
        this.callback = callback;
        this.leftLineFollower = new LineFollower(Config.leftLineFollowerPin) ;
        this.middleLineFollower = new LineFollower(Config.middleLineFollowerPin);
        this.rightLineFollower = new LineFollower(Config.rightLineFollowerPin);
    }

    public void update() {
        if (!this.leftLineFollower.isOnLine()) {
            this.callback.onLineDetectionUpdate(LineDirection.RIGHT);
        } else if (!this.rightLineFollower.isOnLine()) {
            this.callback.onLineDetectionUpdate(LineDirection.LEFT);
        } else {
            this.callback.onLineDetectionUpdate(LineDirection.FORWARD);
        }
    }
}
