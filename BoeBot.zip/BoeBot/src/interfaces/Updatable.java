package interfaces;

public interface Updatable {
    void update();
}