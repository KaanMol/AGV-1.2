package interfaces.hardware;

public interface Movement {
    void forward();
    void backward();
    void turnRight();
    void turnLeft();
}